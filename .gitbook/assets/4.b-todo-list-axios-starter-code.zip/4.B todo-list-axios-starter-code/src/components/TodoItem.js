import React, { Component } from 'react';

export default class TodoItem extends Component {
  render() {
    return (
      <div className="todo-item">
        {/* <h3>todo item</h3> */}
        <p>TITLE: {/* ???? */ }</p>
      </div>
    );
  }
}
