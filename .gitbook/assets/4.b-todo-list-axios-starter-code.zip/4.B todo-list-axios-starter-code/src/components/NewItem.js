import React, { Component } from 'react';

export default class NewItem extends Component {
  constructor(props) {
    super();
    this.state = {
      textInput: '',
    };
  }

  addNew = (e) => {
    // ??????????????
    // this.props.??????(????????);

    // EXTRA
    this.setState({ textInput: '' });
  };

  render() {
    return (
      <div className="new-item">
        <form>
          <input
            type="text"
            placeholder="new todo title"
            onChange={(e) => {
              // ???????????????
            }}
            // EXTRA
            value={this.state.textInput}
          />
          <button >Add</button>
        </form>
      </div>
    );
  }
}
