import React, { Component } from 'react';


export default class TodoList extends Component {
  render() {
    
    // const todoList = ????.map((????, i) => {
    //   return <?????? ??????={?????} key={?} />;
    // });

    return (
      <div className="todo-list">
        <h3>TODO LIST</h3>
        {/* ???????? */}
      </div>
    );
  }
}
