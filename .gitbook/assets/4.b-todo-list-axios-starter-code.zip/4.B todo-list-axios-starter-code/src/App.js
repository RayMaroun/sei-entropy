import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor(props) {
    super();
    this.state = {
      tasks: [],
    };
  }

  componentDidMount() {
    // ??????????????????
  }

  getAllTasks = () => {
    console.log('send API GET /tasks');
  };

  deleteAllTasks = () => {
    console.log('send API DELETE /tasks');
  };

  recoverOldTasks = () => {
    console.log('send API POST /recover');
  };

  tafweedChangeState = (newTask) => {
    console.log('send API POST /tasks');
  };

  render() {
    // console.log('APP: ', this);
    return (
      <div className="app">
        <h3>APP</h3>
        <button >GET ALL TASKS</button>
        <button >DELETE ALL TASKS</button>
        <button >RECOVER ALL TASKS</button>

        <NewItem />
        <TodoList tasks_2={this.state.tasks} />
      </div>
    );
  }
}

export default App;
