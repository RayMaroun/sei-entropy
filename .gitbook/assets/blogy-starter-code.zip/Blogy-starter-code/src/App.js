import React, { Component } from 'react';
import './App.css';

import Post from './components/Post';

class App extends Component {

  render() {
    console.log('APP: ', this);
    return (
      <div className="app">
        <h3>APP</h3>
        <Post /* ???? */ />
      </div>
    );
  }
}

export default App;
