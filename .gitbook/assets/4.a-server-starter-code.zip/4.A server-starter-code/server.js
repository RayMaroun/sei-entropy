// to run this server run npm run server

const express = require('express');
const cors = require('cors');

const app = express();

app.use(express.json());
app.use(cors());

let tasks = ['eat', 'coding', 'sleep'];
let oldTasks = [...tasks];
app.get('/', (req, res) => {
  res.send(`Hello how are you? 
  I think you want => 
  'http://localhost:5000/tasks'`);
});

app.get('/tasks', (req, res) => {
  res.send(tasks);
});

app.post('/tasks', (req, res) => {
  if (req.body.title) {
    tasks.push(req.body.title);
    res.status(200).send(tasks);
  } else {
    res.status(500).send(`you need to have a key in the body  
    called => title
    with a value not empty string
    `);
  }
});

app.delete('/tasks', (req, res) => {
  tasks = [];
  res.send(tasks);
});

app.post('/recover', (req, res) => {
  if (req.body.recover === 'YES') {
    tasks = [...oldTasks];
    res.status(200).send('Now you can Get Them');
  } else {
    res.status(500).send(`you need to have a key in the body  
    called => recover
    with a value => YES
    to can recover the main tasks
    `);
  }
});

// EXTRA
app.put('/tasks/:id', (req, res) => {
  tasks[req.params.id] = req.body.newTitle;
  res.send(tasks);
});

app.delete('/tasks/:id', (req, res) => {
  tasks.splice(req.params.id, 1);
  res.send(tasks);
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`SERVER ARE WORKING ON: http://localhost:${PORT}`);
});
