/* 
React:
-reach anything inside the component => THIS 

-state:values will change same component
-reach a value in state keyName

-set the state use: 
setState({keyName : newValue})

-check nested component:
create => export => import => use

-props:pass some info to another component
nameOfTheProps = value
-reach a value in props propsName

-attached a function to a button: onClick = {functionName}
onClick = {(e)=>{
  //CODE HERE
  functionName()
}}

IMPORTANT NOTE:
You can be sure the API is working
go inside `4.A server` directory, 
then run `npm run server`
if you see this message everything awesome
API IS WORKING ON: http://localhost:5000

=============================================
=============================================
=============================================

Endpoints:

0. API_URL => http://localhost:5000

1. GET / 
=> note

2. GET /tasks
=> array of tasks (string)

3. POST /tasks
should have a body { title:'NEW_TASK'}
=> [..., 'NEW_TASK']

4. DELETE /tasks 
=> []

5. POST /recover 
should have a body { recover:'YES'}
=> recover the data for you

=============================================
=============================================
=============================================

Axios snippet:

1. create it (already online)
2. export it (ity is in nmp)

3. IMPORT IT:
A. install axios: `npm install axios`
B. import axios not AXOIS
import axios from 'axios';

4. use it => axios

axios
  .get(`http://localhost:5000/tasks`)
  .then((response) => {
    console.log('RESPONSE: ', response);
    console.log('DATA: ', response.data);
    // HERE IS YOUR LOGIC
  })
  .catch((err) => {
    console.log('ERR: ', err);
  });

  - post second parameter object represent the body
=============================================
=============================================
 =============================================
Extra:

1. 




*/
