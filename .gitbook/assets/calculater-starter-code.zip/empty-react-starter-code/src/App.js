import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor(props) {
    super();
    this.state = {
      hi: 'hello',
    };
  }

  render() {
    // console.log('APP: ', this);
    return (
      <div className="app">
        <h3>APP</h3>
      </div>
    );
  }
}

export default App;
