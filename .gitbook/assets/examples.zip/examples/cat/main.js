// We loaded axios library in our html file
// Lets make an ajax call with axios

// method: get
// url: https://cataas.com/cat
